<?php

// Configura la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Usuarios";

// Habilitar errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Iniciar el buffer de salida
ob_start();

// Crea una conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener datos del formulario
if (isset($_POST['name']) && isset($_POST['lastName']) && isset($_POST['email']) && isset($_POST['password'])) {
    $name = $_POST['name'];
    $last_name = $_POST['lastName'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validar el formato del correo electrónico
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("El formato del correo electrónico no es válido.");
    }

    // Hacer hash de la contraseña
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Preparar la consulta SQL
    $sql = "INSERT INTO usuarios (nombre, apellido, email, contraseña) VALUES (?, ?, ?, ?)";

    // Preparar la declaración
    $stmt = $conn->prepare($sql);

    // Verificar si la preparación fue exitosa
    if ($stmt === false) {
        die('Error al preparar la consulta: ' . $conn->error);
    }

    // Enlazar parámetros
    $stmt->bind_param("ssss", $name, $last_name, $email, $hashed_password);

    // Ejecutar la declaración
    if ($stmt->execute()) {
        header("Location: ../SemilleroIngles/Login.html");
    } else {
        echo "Error al registrar: " . $stmt->error;
    }

    // Cerrar la declaración y la conexión
    $stmt->close();
} else {
    echo "Faltan datos del formulario.";
}

$conn->close();

// Cerrar el buffer de salida
ob_end_flush();

?>
